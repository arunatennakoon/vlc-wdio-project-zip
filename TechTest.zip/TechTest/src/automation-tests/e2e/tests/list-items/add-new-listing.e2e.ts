import { ChosePackagePage } from '@pages/listing-new-item/chose-package-page';
import { ConfirmPage } from '@pages/listing-new-item/confirm-page';
import { ListingDetailsPage } from '@pages/listing-new-item/listing-details-page';
import { ListingPage } from '@pages/listing-new-item/listing-page';
import { PaymentAndShippingPage } from '@pages/listing-new-item/payment-and-shipping-page';
import { PhotoPage } from '@pages/listing-new-item/photo-page';
import { PriceAndDurationPage } from '@pages/listing-new-item/price-and-duration-page';
import { SummaryPage } from '@pages/listing-new-item/summary-page';
import { LoginPage } from '@pages/login/login-pages';

describe('Test adding a new list', () => {
  const loginPage = new LoginPage();
  const listingPage = new ListingPage();
  const listingDetailsPage = new ListingDetailsPage();
  const paymentAndShippingPage = new PaymentAndShippingPage();
  const priceAndDurationPage = new PriceAndDurationPage();
  const photoPage = new PhotoPage();
  const chosePackage = new ChosePackagePage();
  const confirmPage = new ConfirmPage();
  const summaryPage = new SummaryPage();



  beforeAll(async () => {
    await loginPage.gotoPage();
  });

  it('adding a new list', async () => {
    await listingPage.addItemAndCategory('item1');
    await listingDetailsPage.addListingDetails('item1 description');
    await priceAndDurationPage.addPriceDetails('100');
    await paymentAndShippingPage.addShippingDetails();
    await photoPage.continueWithouPhoto();
    await chosePackage.chosePackage();
    await confirmPage.startAuction();
    await summaryPage.validateSummaryHeaderText('Your auction has started');
  });
});
