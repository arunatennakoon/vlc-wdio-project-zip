export interface TimerOptions {
  startTime: number;
  timeout: number;
}
