export interface Sites {
  url: string;
}
