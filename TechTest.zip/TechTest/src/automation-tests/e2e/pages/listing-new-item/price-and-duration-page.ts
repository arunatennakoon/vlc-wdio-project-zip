import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class PriceAndDurationPage extends Base {
  base = new BaseElements();

  public async addPriceDetails(startPrice: string): Promise<void> {
    await (await this.base.startPriceBox).setValue(startPrice);
    await (await this.base.pricingNextButton).click();
  }
}

