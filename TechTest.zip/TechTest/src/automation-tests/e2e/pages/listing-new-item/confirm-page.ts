import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class ConfirmPage extends Base {
  base = new BaseElements();

  public async startAuction(): Promise<void> {
    await (await this.base.startMyAuctionButton).click();
  }
}

