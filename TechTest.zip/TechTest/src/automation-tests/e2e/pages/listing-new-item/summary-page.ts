import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class SummaryPage extends Base {
  base = new BaseElements();

  public async validateSummaryHeaderText(text: string): Promise<void> {
    expect(await this.base.auctionStartedLabel).toHaveText(text);
  }
}

