import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class PaymentAndShippingPage extends Base {
  base = new BaseElements();

  public async addShippingDetails(): Promise<void> {
    await (await this.base.iDontKnowShippingCostRadio).click();
    await (await this.base.cashPaymentMethodRadio).click();
    await (await this.base.paymentNextButton).click();
  }
}

