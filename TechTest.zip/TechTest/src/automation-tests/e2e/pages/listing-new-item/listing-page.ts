import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class ListingPage extends Base {
  base = new BaseElements();

  public async addItemAndCategory(item: string): Promise<void> {
    // Navigate to listing page
    await browser.url('/Sell/Category.aspx?group=GENERAL&rptpath=1-&fromLink=general');
    await (await this.base.listItemTitleBox).setValue(item);
    await (await this.base.selectCategoryDropdown).click();
    await (await this.base.browseAllCategoriesDropdownItem).click();
    await (await this.base.category1TableOption).click();
    await (await this.base.category2TableOption).click();
    await (await this.base.listInOnlyOneRadio).click();
    await (await this.base.categoryNextbutton).click();
  }

}
