import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class ChosePackagePage extends Base {
  base = new BaseElements();

  public async chosePackage(): Promise<void> {
    await (await this.base.galleryCheckBox).click();
    await (await this.base.chosePackageNextButton).click();
  }
}


