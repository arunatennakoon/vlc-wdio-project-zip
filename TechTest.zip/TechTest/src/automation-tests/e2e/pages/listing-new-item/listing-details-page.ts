import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class ListingDetailsPage extends Base {
  base = new BaseElements();

  public async addListingDetails(description: string): Promise<void> {
    await (await this.base.descriptionBox).setValue(description);
    await (await this.base.listingDetailsNextButton).click();
  }
}
