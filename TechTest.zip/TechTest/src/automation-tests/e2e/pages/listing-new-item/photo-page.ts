import { Base } from '@pages/base';
import { BaseElements } from '@pages/base-elements';

export class PhotoPage extends Base {
  base = new BaseElements();

  public async continueWithouPhoto(): Promise<void> {
    await (await this.base.continueWithouPhotoButton).click();
  }
}

