/**
* Base element for login Page.
*
* @remarks N/A
* @param N/A
* @returns N/A
*
*/
export class BaseElements {
  // login
  get email () { return $('#Email'); }
  get password () { return $('#Password'); }
  get loginButton () { return $('button#SignIn'); }

  // logout
  get logoutButton () { return $('form[action*="Members/Logout"]'); }

  // default search page
  get searchBox () { return $('input#searchString'); }
  get userProfileName () { return $('form[action*="Members/Logout"] p'); }

  //listing page
  get listItemTitleBox () { return $('#listing-title'); }
  get selectCategoryDropdown () {return $('.selectric .dropdown-select');}
  get browseAllCategoriesDropdownItem () { return $('.browse-categories.last');}
  get category1TableOption () { return $('#selector_0 option:nth-child(1)');}
  get category2TableOption () { return $('#selector_1 option:nth-child(1)');}
  get listInOnlyOneRadio () { return $('#one-category-radio');}
  get categoryNextbutton () { return $('#submit_button');}

  //listing details page
  get descriptionBox () { return $('textarea[name=\'body\']');}
  get listingDetailsNextButton () { return $('#submit1');}

  //price and duration
  get startPriceBox () { return $('#startPriceInput');}
  get pricingNextButton () { return $('#submit1');}

  //payment and shipping
  get iDontKnowShippingCostRadio () { return $('#deliveryIdk');}
  get cashPaymentMethodRadio () { return $('"#payment_cash_on_pickup');}
  get paymentNextButton () { return $('#submit1');}

  //add photo page
  get continueWithouPhotoButton () { return $('#ContinueUpload');}

  //chose package page
  get galleryCheckBox () { return $('#medium .relists-unpurchased label');}
  get chosePackageNextButton () { return $('#promo-submit');}

  //ConfirmPage
  get startMyAuctionButton () { return $('#submit_sell');}

  //auction summary page
  get auctionStartedLabel () { return $('#mainContent h1');}






}
